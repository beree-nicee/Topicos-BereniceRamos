package org.example;

public interface ComisionStrategy {
    double calcularComision(double monto);
}